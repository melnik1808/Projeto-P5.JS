let infoAgricultura, infoConsumo;
let inputSugestao, botaoEnviar;
let sugestoes = [];

function setup() {
  noCanvas(); // Sem canvas, só elementos HTML

  createElement('h1', 'Festejando a conexão campo e cidade 🌱🌆');

  infoAgricultura = createElement('h2',
    '🤍 A conexão entre cidade e campo é fundamental para o desenvolvimento sustentável e a qualidade de vida da população. As áreas urbanas concentram a maioria das pessoas, oferecendo oportunidades de trabalho e acesso a serviços. 🤍'
  );

  infoConsumo = createElement('h2',
    '✨ Promover uma integração entre esses dois mundos é essencial. A valorização da agricultura familiar e o incentivo a práticas sustentáveis fortalecem a economia rural e oferecem às cidades uma alimentação saudável e diversificada. ✨'
  );

  createElement('h2', '💫 Entrevista 💫');
  createP('Entrevista com Agricultor Mario Ferreira:');

  // Vídeo do YouTube incorporado via iframe
  let containerVideo = createDiv();
  containerVideo.html(`
    <iframe width="400" height="240"
      src="https://www.youtube.com/embed/y7cPssAFUD0"
      title="Entrevista com Agricultor"
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      allowfullscreen>
    </iframe>
  `);

  createElement('h3', '🤍 Na sua opinião, quais são os benefícios de morar no campo ou na cidade? 🤍');

  inputSugestao = createInput();
  inputSugestao.attribute('placeholder', 'Escreva aqui sua opinião...');
  inputSugestao.style('width', '300px');
  botaoEnviar = createButton('Enviar ❤️');
  botaoEnviar.mousePressed(enviarSugestao);
}

function enviarSugestao() {
  const texto = inputSugestao.value();
  if (texto.trim() !== '') {
    sugestoes.push(texto);
    createP(`• ${texto}`);
    inputSugestao.value('');
  }
}